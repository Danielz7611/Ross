# RTL Lint Report

## Summary

- **Project:** packet_processor ([packet_processor.xpr](../../packet_processor/packet_processor.xpr))
- **Top Module:** `packet_processor`
- **Part Number:** xcvu9p-flga2104-2L-e
- **Vivado Version:** 2025.2
- **Raw Lint Report:** [linter.rpt](./linter.rpt) | **Parsed CSV:** [linter.csv](./linter.csv)
- **Analysis Status:** ISSUES FOUND
- **Critical Warnings:** 7 | **Warnings:** 1 | **Info:** 0

## Vivado Lint Results

**Vivado Output:** "Total of 8 linter message(s) generated"

### By rule ID

| Rule ID  | Severity         | Count | % of total |
|----------|------------------|-------|------------|
| INFER-1  | CRITICAL WARNING | 4     | 50.0%      |
| INFER-2  | CRITICAL WARNING | 2     | 25.0%      |
| ASSIGN-3 | CRITICAL WARNING | 1     | 12.5%      |
| ASSIGN-6 | WARNING          | 1     | 12.5%      |

### By source file (hotspots)

| File | Violations | Rules |
|------|-----------|-------|
| [packet_processor.sv](../../src/packet_processor.sv) | 8 | INFER-1, INFER-2, ASSIGN-3, ASSIGN-6 |

## Violations

### Shift Overflow — ASSIGN-3

**Location**: [packet_processor.sv:116](../../src/packet_processor.sv#L116)

**Issue Description**: Right-hand side of operator `>>` in `(rx_data[3:0] >> 14)` exceeds the range of the left-hand side. LHS width: 13, RHS value: 14. The result is always 0.

**Problematic Code** *(from original source)*:
```diff
                 ST_HEADER: begin
                     dest_addr <= base_addr + rx_data;
                     pkt_priority <= rx_data;
-                    payload_offset <= rx_data[3:0] >> 14;   // ERROR: shift of 14 >= width 13, always yields 0
                 end
                 ST_PAYLOAD: begin
                     crc_accum  <= crc_accum ^ rx_data;
```

**Recommended Fix** *(shift amount must be in 0..width-1; the intended amount depends on design intent, `2` shown as example)*:
```diff
                 ST_HEADER: begin
                     dest_addr <= base_addr + rx_data;
                     pkt_priority <= rx_data;
+                    payload_offset <= rx_data[3:0] >> 2;   // FIXED: valid shift amount within operand width
                 end
                 ST_PAYLOAD: begin
                     crc_accum  <= crc_accum ^ rx_data;
```

**Rationale**: Per IEEE 1364-2005 §5.1.13, a logical shift by an amount greater than or equal to the operand width always yields zero, producing dead logic. Confirm the intended shift (or intended left shift / zero-extension) with the design owner.

**Vivado Documentation**: UG901 Ch.3 "Shift Operators"; IEEE 1364-2005 §5.1.13.

### Signal Assigned But Not Read — ASSIGN-6

**Location**: [packet_processor.sv:48](../../src/packet_processor.sv#L48)

**Issue Description**: Signal `debug_status` was assigned but not read (first unread bit index 0). Synthesis removes the register (`debug_status_reg`).

**Problematic Code** *(from original source)*:
```diff
     logic [DATA_WIDTH-1:0]   crc_accum;
     logic                    crc_ok;
     logic                    pkt_active;
-    logic [7:0]              debug_status;   // Remove unused signal declaration
     logic [4:0]              pkt_priority;
     logic [12:0]             payload_offset;
```

**Recommended Fix**:
```diff
     logic [DATA_WIDTH-1:0]   crc_accum;
     logic                    crc_ok;
     logic                    pkt_active;
-    logic [7:0]              debug_status;   // Remove unused signal declaration
     logic [4:0]              pkt_priority;
     logic [12:0]             payload_offset;
```
and remove its assignment block near the end of the module:
```diff
-    always_ff @(posedge clk or negedge rst_n) begin   // Remove whole block: only assigns debug_status
-        if (!rst_n)
-            debug_status <= 8'h00;
-        else
-            debug_status <= {pkt_active, crc_ok, rx_valid, curr_state, 2'b00};
-    end
```

**Rationale**: Dead code with no functional impact. If debug visibility is required, expose it through an output port or a `mark_debug` attribute instead.

**Vivado Documentation**: UG901 "Unused Logic Optimization"; UG949.

### Latch Inference (next_state) — INFER-1

**Location**: [packet_processor.sv:69](../../src/packet_processor.sv#L69)

**Issue Description**: Inferred latch for `next_state_reg`. Pattern P2: the `case (curr_state)` does not cover all 3-bit encodings (`3'b101`–`3'b111`) and has no `default`.

**Problematic Code** *(from original source)*:
```diff
     always_comb begin
         case (curr_state)
             ST_IDLE: begin
                 if (rx_valid)
-                    next_state = ST_HEADER;   // ERROR: next_state not assigned for unlisted state encodings -> latch
                 else
                     next_state = ST_IDLE;
```

**Recommended Fix**:
```diff
             ST_FORWARD: begin
                 next_state = ST_IDLE;
             end
+            default: next_state = ST_IDLE;   // FIXED: unused encodings return to IDLE, no latch
         endcase
     end
```

**Rationale**: Combinational blocks must assign every output on every path. Fixing the missing `default` (see INFER-2 at line 66) resolves this latch.

**Vivado Documentation**: UG901 Ch.4.3.1.

### Latch Inference (tx_data) — INFER-1

**Location**: [packet_processor.sv:138](../../src/packet_processor.sv#L138)

**Issue Description**: Inferred latch for `tx_data_reg`. Pattern P2: `case (mode_sel)` covers only `3'b000`–`3'b011`; `3'b100`–`3'b111` leave the output unassigned.

**Problematic Code** *(from original source)*:
```diff
     always_comb begin
         case (mode_sel)
             3'b000: begin
-                tx_data  = rx_data;   // ERROR: tx_data not assigned when mode_sel is 3'b1xx -> latch
                 tx_valid = pkt_active & rx_valid;
                 rx_ready = 1'b1;
             end
```

**Recommended Fix**: see consolidated fix below (also resolves `tx_valid_reg` and `rx_ready_reg`).
```diff
             3'b011: begin
                 tx_data  = rx_data;
                 tx_valid = 1'b0;
                 rx_ready = 1'b0;
             end
+            default: begin
+                tx_data  = '0;      // FIXED: safe defaults for unused mode_sel values
+                tx_valid = 1'b0;
+                rx_ready = 1'b0;
+            end
         endcase
     end
```

**Rationale**: Explicit assignment of all outputs for every `mode_sel` value removes the latch.

**Vivado Documentation**: UG901 Ch.4.3.1.

### Latch Inference (tx_valid) — INFER-1

**Location**: [packet_processor.sv:139](../../src/packet_processor.sv#L139)

**Issue Description**: Inferred latch for `tx_valid_reg`, same root cause as `tx_data_reg`.

**Problematic Code** *(from original source)*:
```diff
             3'b000: begin
                 tx_data  = rx_data;
-                tx_valid = pkt_active & rx_valid;   // ERROR: tx_valid not assigned for mode_sel 3'b100-3'b111 -> latch
                 rx_ready = 1'b1;
             end
```

**Recommended Fix**: the `default` branch shown under `tx_data` (line 138) assigns `tx_valid = 1'b0;`.

### Latch Inference (rx_ready) — INFER-1

**Location**: [packet_processor.sv:140](../../src/packet_processor.sv#L140)

**Issue Description**: Inferred latch for `rx_ready_reg`, same root cause as `tx_data_reg`.

**Problematic Code** *(from original source)*:
```diff
                 tx_data  = rx_data;
                 tx_valid = pkt_active & rx_valid;
-                rx_ready = 1'b1;   // ERROR: rx_ready not assigned for mode_sel 3'b100-3'b111 -> latch
             end
             3'b001: begin
```

**Recommended Fix**: the `default` branch shown under `tx_data` (line 138) assigns `rx_ready = 1'b0;`.

### Incomplete Case Statement (next-state) — INFER-2

**Location**: [packet_processor.sv:66](../../src/packet_processor.sv#L66)

**Issue Description**: Case statement items not fully specified and no `default` item. `curr_state` is 3 bits (8 encodings) but only 5 are listed (pattern C5/C2).

**Problematic Code** *(from original source)*:
```diff
     always_comb begin
-        case (curr_state)   // ERROR: 5 of 8 encodings handled, no default
             ST_IDLE: begin
                 if (rx_valid)
                     next_state = ST_HEADER;
```

**Recommended Fix**: add the `default: next_state = ST_IDLE;` item shown under the `next_state` INFER-1 violation (line 69).

**Rationale**: INFER-2 is the root cause of the paired INFER-1 on `next_state_reg`; `full_case` pragmas are not a substitute for `default`.

**Vivado Documentation**: UG901 Ch.4.3.5.

### Incomplete Case Statement (mode select) — INFER-2

**Location**: [packet_processor.sv:136](../../src/packet_processor.sv#L136)

**Issue Description**: Case statement items not fully specified and no `default` item. `mode_sel` is 3 bits (8 values) but only `3'b000`–`3'b011` are listed (pattern C4).

**Problematic Code** *(from original source)*:
```diff
     always_comb begin
-        case (mode_sel)   // ERROR: 4 of 8 encodings handled, no default
             3'b000: begin
                 tx_data  = rx_data;
                 tx_valid = pkt_active & rx_valid;
```

**Recommended Fix**: add the `default` branch shown under the `tx_data` INFER-1 violation (line 138).

**Rationale**: Root cause of the three INFER-1 violations on `tx_data_reg`, `tx_valid_reg` and `rx_ready_reg`.

**Vivado Documentation**: UG901 Ch.4.3.5.

## Recommendations

**Immediate (critical, fix before synthesis)**
1. Add `default` to the `case (curr_state)` at line 66 and the `case (mode_sel)` at line 136. This resolves all 2 INFER-2 and all 4 INFER-1 violations (6 of 8).
2. Correct the shift amount at line 116 (ASSIGN-3). Confirm the intended value with the design owner.

**Design cleanup**
3. Remove `debug_status` and its `always_ff` block (ASSIGN-6), or route it to an output / `mark_debug`.

**Related observations from synthesis log (not lint violations)**
- `pkt_priority_reg` and `payload_offset_reg` were also removed as unused sequential elements (lines 115-116), indicating those signals are never read.

## Next Steps

- Apply the fixes above and re-run the lint: `synth_design -top packet_processor -part xcvu9p-flga2104-2L-e -lint -file linter.rpt`
- Expected after fixes: 0 INFER-1, 0 INFER-2, 0 ASSIGN-3, 0 ASSIGN-6.
